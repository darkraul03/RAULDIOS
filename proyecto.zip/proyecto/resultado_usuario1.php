<!doctype html>
<html>
	<head>
		<title>Resultado Usuario</title>
		<link rel="stylesheet" href="estilos/estilos_registro.css" type="text/css" > 
	</head>
	<body>

		<div class="contenedor-formulario">
	 		<div class="wrap">
			    <h1>Usuario registrado </h1>		
				<form action="procesar_usuario1.php" method="post">
					<a href="registro_usuario1.php">Regresar</a>
				</form>
			</div>
		</div>
	</body>
</html>