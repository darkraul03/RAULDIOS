<?php
	
	mysql_connect('localhost','root') or die(mysql_error());
	mysql_select_db('bd_finnder');
	$profesor=mysql_query("SELECT * FROM tb_profesor") or die(mysql_error());
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Cargar combo</title>
	<link rel="stylesheet" href="estilos/estilos_listado.css" type="text/css" > 
	<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
</head>
<body>
	<h2>Cargando combo y listando</h2>
	<form action="" method="post" >
		<fieldset>
		<legend>Cursos</legend>
		<table>
			<tr>
				<td>Curso</td>
				<td>
					<input type="text" id="curso" name="curso" class="txt-box-campos" tabindex="1">
				</td>
			</tr>
			<tr>
				<td>Universidad</td>
				<td>
					<select id="universidad" class="txt-box-campos" style="width: 270px;" tabindex="2">
						<option>Seleccione una Opcion...</option>
						<?php 
							$consulta=mysql_query("SELECT iIdUniversidad,vNombre from tb_universidad") or die(mysql_error());
							while($fila = mysql_fetch_array($consulta)){
								echo'<OPTION VALUE="'.$fila['iIdUniversidad'].'">'.$fila['vNombre'].'</OPTION>';
							}
						?>
					</select>
				</td>
				<td>
					<input type="submit" class="skip" value="Buscar" tabindex="3">
				</td>
			</tr>
		</table><br>
		<table class="grilla">
			<tr>
				<td class="titulo-int">Codigo</td>
				<td class="titulo-int">Nombres</td>
				<td class="titulo-int">Apellidos</td>
				<td class="titulo-int">Curso</td>
				<td class="titulo-int">Universidad</td>
			</tr>
			<?php while($fila = mysql_fetch_assoc($profesor)){ ?>
				<tr>
					<td><?php echo $fila['codigo'] ?></td>
					<td><?php echo $fila['nombres'] ?> </td>
					<td><?php echo $fila['apellidos'] ?></td>
					<td><?php echo $fila['curso'] ?></td>
					<td><?php echo $fila['universidad'] ?></td>
				</tr>
			<?php } ?>
		</table>
	</fieldset>
	</form>
	
	
	<script type="text/javascript">
        $(document).ready(function () {
            $("#curso").focus(function () {
                $(this).removeClass("txt-box-campos").addClass("txt-box-campos-obliga");
            });
            $("#curso").blur(function () {
                $(this).removeClass("txt-box-campos-obliga").addClass("txt-box-campos");
                $(this).removeClass("txt-box-campos-oblig").addClass("txt-box-campos");
            });
            $("#universidad").focus(function () {
                $(this).removeClass("txt-box-campos").addClass("txt-box-campos-obliga");
            });
            $("#universidad").blur(function () {
                $(this).removeClass("txt-box-campos-obliga").addClass("txt-box-campos");
                $(this).removeClass("txt-box-campos-oblig").addClass("txt-box-campos");
            });
        });
    </script>
</body>
</html>