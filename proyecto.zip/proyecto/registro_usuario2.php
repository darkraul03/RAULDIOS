<!DOCTYPE html>
<html lang="en">
<head>
	<title>Formulario</title>
	<link rel="stylesheet" href="estilos/estilos_listado.css" type="text/css" > 
	<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

    <script>

        $(function () {
            $.datepicker.setDefaults($.datepicker.regional["es"]);
            $("#fecha").datepicker({
                dateFormat: 'dd/mm/yy',
                firstDay: 1
            }).datepicker("setDate", new Date());
        });
    </script>
</head>

<body>
	<span class="titulo">Registro de Usuario</span>
	<form action="" method="post">
		<fieldset>
		<legend class="subtitulo-int">Datos</legend>
			<table>
				<tr>
					<td>
						<span>FECHA DE REGISTRO</span>
					</td>
					<td>
	                    <input type="text" id="fecha" class="txt-box-campos" disabled="disabled" tabindex="1" />
	                </td>
				</tr>
				<tr>
					<td>
						<span>NOMBRES</span>
					</td>
					<td>
						<input type="text" id="nombres" name="nombres" class="txt-box-campos" tabindex="2">
					</td>
				</tr>
				<tr>
					<td>
						<span>APELLIDOS</span>
					</td>
					<td>
						<input type="text" id="apellidos" name="apellidos" class="txt-box-campos" tabindex="3">
					</td>
				</tr>
				<tr>
					<td>
						<span>CORREO</span>
					</td>
					<td>
						<input type="email" id="correo" name="correo" class="txt-box-campos" tabindex="4">
					</td>
				</tr>
				<tr>
					<td>
						<span>CONTRASEÑA</span>
					</td>
					<td>
						<input type="password" id="pass" name="pass" class="txt-box-campos" tabindex="5">
					</td>
				</tr>
				<tr>
					<td>
						<span>REPETIR CONTRASEÑA</span>
					</td>
					<td>
						<input type="password" id="pass2" name="pass2" class="txt-box-campos" tabindex="6">
					</td>
				</tr>
			</table><br>
		</fieldset><br>
		<input type="submit" value="ENVIAR" id="procesar" class="skip" style="margin-left: 45%;" tabindex="7" />
	</form>
	
	<script type="text/javascript" src="scripts/formulario_registro2.js"></script>
</body>
</html>